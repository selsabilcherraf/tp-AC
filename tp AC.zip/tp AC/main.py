import time
import sys
import os


os.chdir(os.path.dirname(__file__))


# QUESTION 1 
def read_file(file_name):
    values = []
    with open(file_name, "r") as f:
        for line in f:
            values.append(int(line.strip()))
    return values


# QUESTION 2 & 3 


def nombre_occurrences(values_list):
    n = len(values_list)
    occurrences = {}
    iterations = 0
    start_time = time.time()

    for i in range(n):
        count = 0
        
        for j in range(n):
            iterations += 1
            if values_list[j] == values_list[i]:
                count += 1

        occurrences[values_list[i]] = count

        # Progress bar
        progress = (i + 1) * 100 / n
        elapsed = time.time() - start_time
        if progress > 0:
            remaining = (100 - progress) * elapsed / progress
        else:
            remaining = 0

        sys.stdout.write(
            f"\rProgress: {progress:.2f}%, Elapsed: {elapsed:.2f}s, Remaining: {remaining:.2f}s"
        )
        sys.stdout.flush()

    end_time = time.time()

    print(f"\n⏱ Durée totale : {end_time - start_time:.4f}s")
    print("Nombre total d’itérations :", iterations)

    return occurrences


# QUESTION 4 


def nombre_occurrences_ameliore(values_list):
    occurrences = {}
    for value in values_list:
        if value not in occurrences:
            occurrences[value] = 1
        else:
            occurrences[value] += 1
    return occurrences



values = read_file("valeurs_aleatoires.txt")

print("Premières valeurs :", values[:10])
print("Longueur de la liste :", len(values))


values_small = values[:1000]

print("\n=== Début comptage O(n²) sur 1000 éléments ===")
occ_n2 = nombre_occurrences(values_small)

print("\n=== Début comptage optimisé O(n) ===")
occ_n = nombre_occurrences_ameliore(values_small)

print("Fini !")


##################################################
#TRI PAR SÉLECTION (Selection Sort)

def selection_sort(values_list):
    n = len(values_list)
    iterations = 0
    start_time = time.time()

    arr = values_list.copy()  

    for i in range(n):
        min_index = i

        for j in range(i + 1, n):
            iterations += 1
            if arr[j] < arr[min_index]:
                min_index = j

        # swap
        arr[i], arr[min_index] = arr[min_index], arr[i]

    end_time = time.time()

    print("\n=== Selection Sort Results ===")
    print("⏱ Durée d'exécution :", end_time - start_time)
    print("Nombre total d’itérations :", iterations)
    print("Complexité : O(n²)")

    return arr
print("\n=== Début Selection Sort ===")
sorted_selection = selection_sort(values_small)
print("Premiers éléments triés :", sorted_selection[:10])


##################################################
#TRI PAR FUSION (Merge Sort)

def merge_sort(values_list):
    start_time = time.time()
    iterations = {"count": 0}

    def merge(left, right):
        result = []
        i = j = 0

        while i < len(left) and j < len(right):
            iterations["count"] += 1
            if left[i] < right[j]:
                result.append(left[i])
                i += 1
            else:
                result.append(right[j])
                j += 1

        result.extend(left[i:])
        result.extend(right[j:])
        return result

    def divide(lst):
        if len(lst) <= 1:
            return lst

        mid = len(lst) // 2
        left = divide(lst[:mid])
        right = divide(lst[mid:])
        return merge(left, right)

    sorted_list = divide(values_list)

    end_time = time.time()

    print("\n=== Merge Sort Results ===")
    print("⏱ Durée d'exécution :", end_time - start_time)
    print("Nombre total d’itérations :", iterations["count"])
    print("Complexité : O(n log n)")

    return sorted_list
print("\n=== Début Merge Sort ===")
sorted_merge = merge_sort(values_small)
print("Premiers éléments triés :", sorted_merge[:10])


##################################################
def write_to_file(tab):
    with open("valeurs_aleatoires_tries.txt", "w") as f:
        for value in tab:
            f.write(str(value) + "\n")

    print("\nFichier valeurs_aleatoires_tries.txt créé !")

write_to_file(sorted_merge)

##################################################